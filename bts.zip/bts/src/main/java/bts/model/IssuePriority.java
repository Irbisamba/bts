package bts.model;

public enum IssuePriority {
    MINOR,
    NORMAL,
    HIGH,
    CRITICAL,
    BLOCKER
}
